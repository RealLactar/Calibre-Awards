from calibre.customize import InterfaceActionBase


class CalibreAwardsPlugin(InterfaceActionBase):
    """Installable InterfaceActionBase plugin; UI lives in actual_plugin."""

    name = 'Calibre Awards'
    description = 'Find literary awards associated with books and stories'
    supported_platforms = ['windows', 'osx', 'linux']
    author = 'Agris Taurins'
    version = (0, 3, 0)
    # Compatibility metadata for Calibre's plugin loader.
    minimum_calibre_version = (6, 0, 0)
    actual_plugin = 'calibre_plugins.calibre_awards.ui:CalibreAwardsAction'

    def is_customizable(self):
        return True

    def config_widget(self):
        # Import lazily so command-line Calibre tools do not load Qt.
        from calibre_plugins.calibre_awards.config import ConfigWidget

        return ConfigWidget()

    def save_settings(self, config_widget):
        config_widget.save_settings()

