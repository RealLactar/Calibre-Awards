"""Award source adapters."""
