"""Award source adapters."""
