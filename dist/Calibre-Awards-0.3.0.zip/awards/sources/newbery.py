"""Official ALA John Newbery Medal HTML archive source.

Listing pages cover 1930-2023; annual ALA announcements supply 2024-2026.
Historical author confirmation is lazy: only title candidates fetch a
/winner/... page. Announcement authors are separately credited in HTML.
1922-1929 remains out of scope.
A validated listing archive may also be loaded from the injected persistent
cache. Winner-page authors stay RAM-only.
"""

from __future__ import annotations

import re
import threading
import unicodedata
import urllib.error
import urllib.request
from dataclasses import dataclass
from html.parser import HTMLParser
from http.cookiejar import CookieJar
from urllib.parse import urljoin, urlparse

from .. import cache
from ..matching import normalize_title_conjunctions
from ..model import AwardResult

TIMEOUT_SECONDS = 30
AWARD_NAME = 'Newbery Medal'
CATEGORY = "Children's Literature"
SOURCE_NAME = 'John Newbery Medal'
SOURCE_HOME_URL = (
    'https://www.ala.org/alsc/awardsgrants/bookmedia/newbery'
)
DETAIL_ORIGIN = 'https://www.ala.org'

ARCHIVE_URL_2004_2023 = (
    'https://www.ala.org/awards/books-media/john-newbery-medal-2'
)
ARCHIVE_URL_1992_2003 = (
    'https://www.ala.org/awards/books-media/john-newbery-medal'
)
ARCHIVE_URL_1930_1991 = (
    'https://www.ala.org/awards/books-media/john-newbery-medal-1'
)
ARCHIVE_URLS = (
    ARCHIVE_URL_2004_2023,
    ARCHIVE_URL_1992_2003,
    ARCHIVE_URL_1930_1991,
)
# Drupal pages supply historical coverage; annual HTML supplies recent years.
ARCHIVE_MIN_YEAR = 1930
ARCHIVE_MAX_YEAR = 2026
_ARCHIVE_PAGE_SPECS: tuple[tuple[str, int, int], ...] = (
    (ARCHIVE_URL_1930_1991, 1930, 1991),
    (ARCHIVE_URL_1992_2003, 1992, 2003),
    (ARCHIVE_URL_2004_2023, 2004, 2023),
)
_HISTORICAL_PAGE_SPECS = _ARCHIVE_PAGE_SPECS
ANNUAL_URLS = {
    year: (
        f'https://www.ala.org/news/{year}/01/'
        f'american-library-association-announces-{year}-youth-media-award-winners'
    )
    for year in (2024, 2025, 2026)
}
_ARCHIVE_PAGE_SPECS += tuple((url, year, year) for year, url in ANNUAL_URLS.items())
_REVIEWED_HONOR_COUNTS = {2024: 5, 2025: 4, 2026: 4}

SOURCE_KEY = 'newbery'
CACHE_VERSION = 2
# 7-day base plus an explicit stagger. Do not derive from AWARD_SOURCES order.
CACHE_BASE_TTL_SECONDS = 7 * 24 * 60 * 60
CACHE_REFRESH_OFFSET_SECONDS = 3 * 60 * 60
CACHE_TTL_SECONDS = CACHE_BASE_TTL_SECONDS + CACHE_REFRESH_OFFSET_SECONDS

_BROWSER_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/122.0.0.0 Safari/537.36'
    ),
    'Accept': (
        'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    ),
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'identity',
}

_OFFICIAL_HTML_HOSTS = frozenset({'ala.org', 'www.ala.org'})
_DETAIL_SLUG_RE = re.compile(r'^[0-9A-Za-z][0-9A-Za-z_-]*$')
_HEADING_YEAR_RE = re.compile(r'^(\d{4})$')
_WINNER_HONOR_RANK_RE = re.compile(
    r'^(?P<year>\d{4})\s*-\s*(?P<label>Winner|Honor)\(s\)\s*$',
    re.IGNORECASE,
)
_RUNNER_UP_RANK_RE = re.compile(
    r'^(?P<year>\d{4})\s*-\s*Runner(?:-|\s+)up(?:s|\(s\))?\s*$',
    re.IGNORECASE,
)
_INITIALS_SPACE_RE = re.compile(r'\b([A-Za-z])\.\s+')
_QUOTED_TITLE_PREFIX_RE = re.compile(
    r'^(?:'
    r'"[^"]+"'
    r'|\u201c[^\u201d]+\u201d'
    r")\s*"
)
_BYLINE_LEAD_RE = re.compile(
    r'^(?:written\s+by|by)\s+(?P<author>.+)$',
    re.IGNORECASE | re.DOTALL,
)
_PUBLISHER_CUT_RE = re.compile(
    r'[.,]?\s*(?:,\s*)?(?:and\s+)?published\s+by\b.*$',
    re.IGNORECASE | re.DOTALL,
)
_MAX_AUTHOR_LENGTH = 80


class NewberySourceError(RuntimeError):
    """Raised when official Newbery HTML cannot be parsed safely."""


@dataclass(frozen=True, slots=True)
class _ListingRecord:
    """Historical listing row or annual announcement with an explicit author."""

    work_title: str
    award_year: int
    status: str
    detail_url: str
    source_url: str
    work_author: str | None = None


_PARSED_STATUSES = frozenset({'Winner', 'Honor'})
_RECORD_CACHE_FIELDS = (
    'award_year',
    'detail_url',
    'source_url',
    'status',
    'work_title',
    'work_author',
)


class _AnnouncementText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.heading = []
        self.in_heading = False

    def handle_starttag(self, tag, attrs):
        if tag == 'h1':
            self.in_heading = True

    def handle_endtag(self, tag):
        if tag == 'h1':
            self.in_heading = False

    def handle_data(self, data):
        self.parts.append(data)
        if self.in_heading:
            self.heading.append(data)


def _parse_annual_html(
    html: str, year: int, source_url: str,
) -> list[_ListingRecord]:
    """Read writing credits only within the identified Medal/Honor section."""
    parser = _AnnouncementText()
    parser.feed(html)
    parser.close()
    heading = _collapse_ws(' '.join(parser.heading))
    expected_heading = (
        f'American Library Association announces {year} Youth Media Award winners'
    )
    if heading != expected_heading or source_url != ANNUAL_URLS.get(year):
        raise NewberySourceError('Wrong Newbery annual announcement identity')
    text = _collapse_ws(' '.join(parser.parts))
    sections = re.findall(
        r"John Newbery Medal for the most outstanding contribution to children's "
        r'literature:\s*(.*?)Randolph Caldecott Medal for', text,
    )
    if len(sections) != 1 or 'Newbery Honor Books' not in sections[0]:
        raise NewberySourceError('Missing or ambiguous Newbery announcement section')
    section = sections[0]
    citations = list(re.finditer(
        r'[“"]([^”"]+)[”"],?\s+written(?: and illustrated)? by\s+'
        r'([^,;]+?)(?=,|\s+and published\b|\s+is the\b)', section,
    ))
    records = []
    for index, citation in enumerate(citations):
        title = citation[1].rstrip(',').strip()
        author = _collapse_ws(citation[2])
        if not title or not author or len(author) > _MAX_AUTHOR_LENGTH:
            raise NewberySourceError('Missing Newbery announcement work identity')
        follows_honor_heading = 'Newbery Honor Books' in section[:citation.start()]
        if follows_honor_heading != (index > 0):
            raise NewberySourceError('Ambiguous Newbery Medal/Honor boundary')
        records.append(_ListingRecord(
            title, year, 'Winner' if index == 0 else 'Honor',
            source_url, source_url, author,
        ))
    _validate_page_records(records, source_url, year, year)
    return records


def _collapse_ws(text: str) -> str:
    return re.sub(r'\s+', ' ', text).strip()


def _class_set(attrs: list[tuple[str, str | None]]) -> set[str]:
    attr = {name: (value or '') for name, value in attrs}
    return set(attr.get('class', '').split())


def _attr_map(attrs: list[tuple[str, str | None]]) -> dict[str, str]:
    return {name: (value or '') for name, value in attrs}


def _safe_detail_url(href: str | None) -> str | None:
    """Return an official https://www.ala.org/winner/{slug} URL, or None."""
    if not href or not href.strip():
        return None
    resolved = urljoin(f'{DETAIL_ORIGIN}/', href.strip())
    parsed = urlparse(resolved)
    if parsed.scheme != 'https':
        return None
    host = (parsed.hostname or '').casefold().rstrip('.')
    if host not in _OFFICIAL_HTML_HOSTS:
        return None
    parts = [piece for piece in parsed.path.split('/') if piece]
    if len(parts) != 2:
        return None
    kind, slug = parts
    if kind.casefold() != 'winner' or not _DETAIL_SLUG_RE.fullmatch(slug):
        return None
    return f'{DETAIL_ORIGIN}/winner/{slug}'


def _normalize_status(label: str) -> str:
    key = _collapse_ws(label).casefold()
    if key == 'winner':
        return 'Winner'
    if key in {'honor', 'runner-up', 'runner up'}:
        return 'Honor'
    raise NewberySourceError(
        f'Newbery listing row has an unrecognized status {label!r}'
    )


def _parse_rank_text(text: str) -> tuple[int, str]:
    cleaned = _collapse_ws(text)
    match = _WINNER_HONOR_RANK_RE.fullmatch(cleaned)
    if match is not None:
        return int(match.group('year')), _normalize_status(match.group('label'))
    match = _RUNNER_UP_RANK_RE.fullmatch(cleaned)
    if match is not None:
        return int(match.group('year')), 'Honor'
    raise NewberySourceError(
        'Newbery listing row has a malformed award status '
        f'{cleaned!r}; expected "YYYY - Winner(s)" or "YYYY - Honor(s)"'
    )


class _NewberyListingParser(HTMLParser):
    """Parse one ALA Newbery Drupal winners-table page into listing records."""

    def __init__(self, source_url: str) -> None:
        super().__init__(convert_charrefs=True)
        self.source_url = source_url
        self.records: list[_ListingRecord] = []
        self._section_year: int | None = None
        self._in_year_heading = False
        self._heading_buffer: list[str] = []
        self._listing_table_depth = 0
        self._in_thead = False
        self._in_row = False
        self._td_kind: str | None = None
        self._in_title_p = False
        self._title_buffer: list[str] = []
        self._title_href: str | None = None
        self._rank_buffer: list[str] = []
        self._seen: set[tuple[int, str, str, str]] = set()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        classes = _class_set(attrs)
        attr = _attr_map(attrs)

        if tag == 'h3' and 'accordion-item__heading' in classes:
            self._in_year_heading = True
            self._heading_buffer = []
            return

        if tag == 'table' and 'views-table' in classes:
            self._listing_table_depth = 1
            return
        if tag == 'table' and self._listing_table_depth:
            self._listing_table_depth += 1
            return

        if not self._listing_table_depth:
            return

        if tag == 'thead':
            self._in_thead = True
            return
        if self._in_thead:
            return

        if tag == 'tr':
            self._in_row = True
            self._td_kind = None
            self._in_title_p = False
            self._title_buffer = []
            self._title_href = None
            self._rank_buffer = []
            return

        if not self._in_row:
            return

        if tag == 'td':
            if 'views-field-title-1' in classes:
                self._td_kind = 'title'
            elif 'views-field-field-winner-rank' in classes:
                self._td_kind = 'rank'
            else:
                self._td_kind = 'other'
            return

        if tag == 'p' and self._td_kind == 'title':
            self._in_title_p = True
            return

        if tag == 'a' and self._td_kind == 'title' and self._title_href is None:
            self._title_href = attr.get('href') or None

    def handle_endtag(self, tag: str) -> None:
        if tag == 'h3' and self._in_year_heading:
            heading = _collapse_ws(''.join(self._heading_buffer))
            year_match = _HEADING_YEAR_RE.fullmatch(heading)
            self._section_year = int(year_match.group(1)) if year_match else None
            self._in_year_heading = False
            self._heading_buffer = []
            return

        if tag == 'thead' and self._listing_table_depth:
            self._in_thead = False
            return

        if tag == 'p' and self._in_title_p:
            self._in_title_p = False
            return

        if tag == 'td' and self._in_row:
            self._td_kind = None
            self._in_title_p = False
            return

        if tag == 'tr' and self._in_row:
            self._finish_row()
            self._in_row = False
            return

        if tag == 'table' and self._listing_table_depth:
            self._listing_table_depth -= 1

    def handle_data(self, data: str) -> None:
        if self._in_year_heading:
            self._heading_buffer.append(data)
            return
        if self._td_kind == 'title' and not self._in_title_p:
            self._title_buffer.append(data)
            return
        if self._td_kind == 'rank':
            self._rank_buffer.append(data)

    def _finish_row(self) -> None:
        title = _collapse_ws(''.join(self._title_buffer))
        rank_text = _collapse_ws(''.join(self._rank_buffer))
        href = self._title_href
        if not title and not rank_text and not href:
            return
        if not title:
            raise NewberySourceError(
                'Newbery listing row is missing a title for '
                f'{self.source_url}'
            )
        if not rank_text:
            raise NewberySourceError(
                'Newbery listing row is missing an award status for '
                f'{title!r} on {self.source_url}'
            )
        award_year, status = _parse_rank_text(rank_text)
        if (
            self._section_year is not None
            and award_year != self._section_year
        ):
            raise NewberySourceError(
                'Newbery listing row year does not match its accordion '
                f'section: row={award_year}, section={self._section_year} '
                f'for {title!r} on {self.source_url}'
            )
        detail_url = _safe_detail_url(href)
        if detail_url is None:
            raise NewberySourceError(
                'Newbery listing row is missing an official winner URL for '
                f'{title!r} on {self.source_url}'
            )
        key = (
            award_year,
            status.casefold(),
            title.casefold(),
            detail_url.casefold(),
        )
        if key in self._seen:
            return
        self._seen.add(key)
        self.records.append(
            _ListingRecord(
                work_title=title,
                award_year=award_year,
                status=status,
                detail_url=detail_url,
                source_url=self.source_url,
            )
        )


def _parse_listing_html(html: str, source_url: str) -> list[_ListingRecord]:
    """Parse one official Newbery listing page. Malformed rows raise."""
    parser = _NewberyListingParser(source_url)
    parser.feed(html)
    parser.close()
    return parser.records


def _author_from_byline(text: str) -> str | None:
    """Extract a work author from an ALA winner-page byline, or None.

    Stops before publisher information. Does not guess from blurbs.
    """
    cleaned = _collapse_ws(text)
    if not cleaned:
        return None
    remainder = _QUOTED_TITLE_PREFIX_RE.sub('', cleaned, count=1).strip()
    match = _BYLINE_LEAD_RE.fullmatch(remainder)
    if match is None:
        # Some historical headers omit "by", but retain this explicit credit
        # delimiter. Do not accept an arbitrary bare name or About paragraph.
        credit = re.fullmatch(
            r'(?P<author>[^,;.!?]+),\s+and\s+published\s+by\s+\S.*',
            remainder, re.IGNORECASE,
        )
        if credit is None:
            return None
        author = credit.group('author').strip()
    else:
        author = _PUBLISHER_CUT_RE.sub('', match.group('author')).strip()
    author = author.strip(' ,.;')
    if not author:
        return None
    if 'published by' in author.casefold():
        return None
    if len(author) > _MAX_AUTHOR_LENGTH:
        return None
    return author


class _NewberyDetailParser(HTMLParser):
    """Capture the first paragraph after h1; ignore About/body blurbs."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.byline: str | None = None
        self._in_h1 = False
        self._seen_h1 = False
        self._in_byline_p = False
        self._byline_buffer: list[str] = []
        self._byline_done = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == 'h1':
            self._in_h1 = True
            return
        if self._byline_done or self._in_h1:
            return
        if tag == 'h2' and self._seen_h1:
            self._byline_done = True
            return
        if tag == 'p' and self._seen_h1 and not self._in_byline_p:
            self._in_byline_p = True
            self._byline_buffer = []

    def handle_endtag(self, tag: str) -> None:
        if tag == 'h1' and self._in_h1:
            self._in_h1 = False
            self._seen_h1 = True
            return
        if tag == 'p' and self._in_byline_p:
            self.byline = _collapse_ws(''.join(self._byline_buffer))
            self._in_byline_p = False
            self._byline_done = True

    def handle_data(self, data: str) -> None:
        if self._in_byline_p:
            self._byline_buffer.append(data)


def _parse_detail_author(html: str) -> str | None:
    """Return the winner-page byline author, or None if none is usable."""
    parser = _NewberyDetailParser()
    parser.feed(html)
    parser.close()
    if not parser.byline:
        return None
    return _author_from_byline(parser.byline)


def _normalize_text(value: str) -> str:
    text = unicodedata.normalize('NFKC', value)
    text = (
        text.replace('\u2018', "'")
        .replace('\u2019', "'")
        .replace('\u201c', '"')
        .replace('\u201d', '"')
        .replace('\u00b4', "'")
        .replace('`', "'")
    )
    text = _collapse_ws(text)
    text = text.casefold()
    text = _INITIALS_SPACE_RE.sub(r'\1.', text)
    return text


def _titles_match(query_title: str, record_title: str) -> bool:
    query_norm = normalize_title_conjunctions(_normalize_text(query_title))
    record_norm = normalize_title_conjunctions(_normalize_text(record_title))
    if query_norm == record_norm:
        return True

    query_has_subtitle = ':' in query_norm
    record_has_subtitle = ':' in record_norm
    if query_has_subtitle == record_has_subtitle:
        return False

    query_base = (
        query_norm.split(':', 1)[0].strip() if query_has_subtitle else query_norm
    )
    record_base = (
        record_norm.split(':', 1)[0].strip() if record_has_subtitle else record_norm
    )
    return bool(query_base) and query_base == record_base


# Comparison-only. AwardResult.work_author keeps the official ALA spelling.
# The 1972 Tombs of Atuan winner page writes "LeGuin" without a space.
# Keys are _normalize_text results (initials compacted: "K. Le" -> "k.le").
_LE_GUIN_MATCH_FORMS = frozenset({
    'ursula k.leguin',
    'ursula k.le guin',
})
_LE_GUIN_MATCH_KEY = 'ursula k.le guin'


def _author_match_key(author: str) -> str:
    """Return the Newbery author comparison key.

    Exact normalized spelling except for the explicit Le Guin/LeGuin alias.
    """
    normalized = _normalize_text(author)
    if normalized in _LE_GUIN_MATCH_FORMS:
        return _LE_GUIN_MATCH_KEY
    return normalized


def _authors_match(query_author: str, record_author: str) -> bool:
    # Exact normalized strings, plus the explicit Le Guin alias above.
    return _author_match_key(query_author) == _author_match_key(record_author)


def _record_authors_match(
    query_author: str, official_author: str, record: _ListingRecord,
) -> bool:
    if _authors_match(query_author, official_author):
        return True
    # Verified publisher identity; scoped to this exact ALA winning record.
    # See awards/data/newbery_provenance.md. Preserve the official result credit.
    return (
        record.work_title == 'Johnny Tremain'
        and record.award_year == 1944
        and record.status == 'Winner'
        and record.detail_url == 'https://www.ala.org/winner/johnny-tremain'
        and {_normalize_text(query_author), _normalize_text(official_author)}
        == {'esther hoskins forbes', 'esther forbes'}
    )


# ---------------------------------------------------------------------------
# HTTP retrieval
# ---------------------------------------------------------------------------

def _build_opener() -> urllib.request.OpenerDirector:
    return urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(CookieJar())
    )


def _read_response_body(response) -> str:
    return response.read().decode('utf-8', errors='replace')


def _fetch_html(opener: urllib.request.OpenerDirector, url: str) -> str:
    request = urllib.request.Request(url, headers=dict(_BROWSER_HEADERS))
    try:
        with opener.open(request, timeout=TIMEOUT_SECONDS) as response:
            status = getattr(response, 'status', None) or response.getcode()
            html = _read_response_body(response)
    except urllib.error.HTTPError as exc:
        try:
            body = _read_response_body(exc)
            raise NewberySourceError(
                f'Newbery request failed with HTTP {exc.code} for {url}'
                + (f': {body[:200].strip()}' if body.strip() else '')
            ) from exc
        finally:
            exc.close()
    except urllib.error.URLError as exc:
        raise NewberySourceError(
            f'Newbery request failed for {url}: {exc.reason}'
        ) from exc
    except TimeoutError as exc:
        raise NewberySourceError(
            f'Newbery request timed out for {url}'
        ) from exc

    if status != 200:
        raise NewberySourceError(
            f'Newbery request failed with HTTP {status} for {url}'
        )
    return html


# ---------------------------------------------------------------------------
# Archive validation and listing cache
# ---------------------------------------------------------------------------

_listing_records_cache: tuple[_ListingRecord, ...] | None = None
_detail_author_cache: dict[str, str] = {}
_cache_lock = threading.RLock()


def _reset_runtime_state() -> None:
    """Clear in-process listing and detail-author caches. Does not delete disk."""
    global _listing_records_cache
    with _cache_lock:
        _listing_records_cache = None
        _detail_author_cache.clear()


def _in_phase_range(year: int) -> bool:
    return ARCHIVE_MIN_YEAR <= year <= ARCHIVE_MAX_YEAR


def _validate_page_records(
    records: list[_ListingRecord],
    url: str,
    start_year: int,
    end_year: int,
) -> None:
    """Require this page's year range; ignore years outside reviewed coverage."""
    by_year: dict[int, list[_ListingRecord]] = {}
    for record in records:
        year = record.award_year
        if not _in_phase_range(year):
            continue
        if year < start_year or year > end_year:
            raise NewberySourceError(
                f'Newbery archive page {url} contained year {year}, '
                f'which belongs on another listing page'
            )
        by_year.setdefault(year, []).append(record)

    missing = [
        year
        for year in range(start_year, end_year + 1)
        if year not in by_year
    ]
    if missing:
        raise NewberySourceError(
            f'Newbery archive page {url} is missing required years: '
            + ', '.join(str(year) for year in missing)
        )

    for year in range(start_year, end_year + 1):
        winners = [
            record for record in by_year[year] if record.status == 'Winner'
        ]
        if not winners:
            raise NewberySourceError(
                f'Newbery archive page {url} has no Winner for {year}'
            )
        if len(winners) > 1:
            raise NewberySourceError(
                f'Newbery archive page {url} has {len(winners)} Winners '
                f'for {year}'
            )
        if year in _REVIEWED_HONOR_COUNTS:
            group = by_year[year]
            identities = {(_normalize_text(r.work_title), r.status) for r in group}
            if (
                sum(r.status == 'Honor' for r in group) != _REVIEWED_HONOR_COUNTS[year]
                or len(identities) != len(group)
            ):
                raise NewberySourceError(f'Incomplete or duplicate Newbery {year} results')


def _usable_listing_records(
    records: list[_ListingRecord],
) -> tuple[_ListingRecord, ...]:
    return tuple(
        record for record in records if _in_phase_range(record.award_year)
    )


def _validate_combined_archive(records: tuple[_ListingRecord, ...]) -> None:
    if not records:
        raise NewberySourceError(
            'Newbery archive pages were retrieved but no 1930-2026 records '
            'could be parsed'
        )
    by_year: dict[int, list[_ListingRecord]] = {}
    for record in records:
        by_year.setdefault(record.award_year, []).append(record)
    missing = [
        year
        for year in range(ARCHIVE_MIN_YEAR, ARCHIVE_MAX_YEAR + 1)
        if year not in by_year
    ]
    if missing:
        raise NewberySourceError(
            'Newbery combined archive is missing required years: '
            + ', '.join(str(year) for year in missing)
        )
    for year in range(ARCHIVE_MIN_YEAR, ARCHIVE_MAX_YEAR + 1):
        winners = [
            record for record in by_year[year] if record.status == 'Winner'
        ]
        if len(winners) != 1:
            raise NewberySourceError(
                'Newbery combined archive does not have exactly one Winner '
                f'for {year}'
            )


def _load_listing_records() -> tuple[_ListingRecord, ...]:
    """Fetch historical listings and reviewed annual announcements through 2026."""
    opener = _build_opener()
    combined: list[_ListingRecord] = []
    for url, start_year, end_year in _ARCHIVE_PAGE_SPECS:
        html = _fetch_html(opener, url)
        records = (
            _parse_annual_html(html, start_year, url)
            if start_year in ANNUAL_URLS else _parse_listing_html(html, url)
        )
        _validate_page_records(records, url, start_year, end_year)
        combined.extend(records)
    usable = _usable_listing_records(combined)
    _validate_combined_archive(usable)
    return usable


def _load_live_archive() -> tuple[_ListingRecord, ...]:
    return _load_listing_records()


# ---------------------------------------------------------------------------
# Persistent listing cache
# ---------------------------------------------------------------------------

def _record_to_cache_dict(record: _ListingRecord) -> dict:
    return {
        'award_year': record.award_year,
        'detail_url': record.detail_url,
        'source_url': record.source_url,
        'status': record.status,
        'work_title': record.work_title,
        'work_author': record.work_author,
    }


def _record_from_cache_dict(data) -> _ListingRecord | None:
    if not isinstance(data, dict) or set(data) != set(_RECORD_CACHE_FIELDS):
        return None
    award_year = data.get('award_year')
    if (
        isinstance(award_year, bool)
        or not isinstance(award_year, int)
        or not _in_phase_range(award_year)
    ):
        return None
    work_title = data.get('work_title')
    status = data.get('status')
    detail_url = data.get('detail_url')
    source_url = data.get('source_url')
    if not isinstance(work_title, str) or not work_title.strip() or work_title != work_title.strip():
        return None
    if status not in _PARSED_STATUSES:
        return None
    if (
        not isinstance(detail_url, str)
        or (
            _safe_detail_url(detail_url) != detail_url
            and detail_url != ANNUAL_URLS.get(award_year)
        )
    ):
        return None
    if source_url not in _listing_source_url_set():
        return None
    author = data.get('work_author')
    if award_year in ANNUAL_URLS:
        if (
            source_url != ANNUAL_URLS[award_year] or detail_url != source_url
            or not isinstance(author, str) or not author.strip()
            or author != author.strip() or len(author) > _MAX_AUTHOR_LENGTH
        ):
            return None
    elif author is not None:
        return None
    return _ListingRecord(
        work_title=work_title,
        award_year=award_year,
        status=status,
        detail_url=detail_url,
        source_url=source_url,
        work_author=author,
    )


def _listing_source_url_set() -> frozenset[str]:
    return frozenset(url for url, _start, _end in _ARCHIVE_PAGE_SPECS)


def _archive_source_urls() -> tuple[str, ...]:
    return tuple(url for url, _start, _end in _ARCHIVE_PAGE_SPECS)


def _coverage_from_records(
    records: tuple[_ListingRecord, ...], *,
    specs=_ARCHIVE_PAGE_SPECS, max_year=ARCHIVE_MAX_YEAR,
) -> dict:
    pages = []
    for url, start_year, end_year in specs:
        subset = [record for record in records if record.source_url == url]
        pages.append(
            {
                'end_year': end_year,
                'record_count': len(subset),
                'start_year': start_year,
                'url': url,
            }
        )
    return {
        'honor_count': sum(1 for record in records if record.status == 'Honor'),
        'max_year': max_year,
        'min_year': ARCHIVE_MIN_YEAR,
        'pages': pages,
        'record_count': len(records),
        'winner_count': sum(1 for record in records if record.status == 'Winner'),
    }


def _validate_cached_archive(records: tuple[_ListingRecord, ...]) -> None:
    """Fail closed if reconstructed listings are not a complete 1930-2026 archive."""
    if not records:
        raise NewberySourceError(
            'Newbery persistent cache contained no listing records'
        )
    by_url: dict[str, list[_ListingRecord]] = {
        url: [] for url, _start, _end in _ARCHIVE_PAGE_SPECS
    }
    for record in records:
        if record.status not in _PARSED_STATUSES:
            raise NewberySourceError(
                'Newbery archive produced an unexpected status: '
                f'{record.status!r}'
            )
        if not _in_phase_range(record.award_year):
            raise NewberySourceError(
                f'Newbery archive year {record.award_year} is outside '
                f'{ARCHIVE_MIN_YEAR}-{ARCHIVE_MAX_YEAR}'
            )
        if (
            _safe_detail_url(record.detail_url) != record.detail_url
            and record.detail_url != ANNUAL_URLS.get(record.award_year)
        ):
            raise NewberySourceError(
                'Newbery archive produced an unexpected detail URL: '
                f'{record.detail_url!r}'
            )
        if record.source_url not in by_url:
            raise NewberySourceError(
                'Newbery archive produced an unexpected listing URL: '
                f'{record.source_url!r}'
            )
        by_url[record.source_url].append(record)
    for url, start_year, end_year in _ARCHIVE_PAGE_SPECS:
        _validate_page_records(by_url[url], url, start_year, end_year)
    _validate_combined_archive(records)


def _records_from_cache_payload(
    payload: dict,
) -> tuple[_ListingRecord, ...] | None:
    expected_urls = list(_archive_source_urls())
    if payload.get('source_urls') != expected_urls:
        return None
    raw_records = payload.get('records')
    if not isinstance(raw_records, list):
        return None
    records: list[_ListingRecord] = []
    for item in raw_records:
        record = _record_from_cache_dict(item)
        if record is None:
            return None
        records.append(record)
    restored = tuple(records)
    try:
        _validate_cached_archive(restored)
    except NewberySourceError:
        return None
    if payload.get('coverage') != _coverage_from_records(restored):
        return None
    return restored


def _load_persistent_archive() -> (
    tuple[tuple[_ListingRecord, ...], dict] | None
):
    payload = cache.load_source_cache(SOURCE_KEY, CACHE_VERSION)
    if payload is None:
        return _load_historical_fallback()
    records = _records_from_cache_payload(payload)
    if records is None:
        return None
    return records, payload


def _load_historical_fallback():
    """Validate schema-1 coverage explicitly; never label it complete through 2026."""
    payload = cache.load_source_cache(SOURCE_KEY, 1)
    if (
        payload is None
        or payload.get('source_urls') != [spec[0] for spec in _HISTORICAL_PAGE_SPECS]
    ):
        return None
    rows = []
    for raw in payload['records']:
        if (
            not isinstance(raw, dict)
            or set(raw) != set(_RECORD_CACHE_FIELDS) - {'work_author'}
        ):
            return None
        row = _record_from_cache_dict(dict(raw, work_author=None))
        if row is None or not 1930 <= row.award_year <= 2023:
            return None
        rows.append(row)
    try:
        for url, start, end in _HISTORICAL_PAGE_SPECS:
            _validate_page_records(
                [r for r in rows if r.source_url == url], url, start, end,
            )
    except NewberySourceError:
        return None
    coverage = _coverage_from_records(
        tuple(rows), specs=_HISTORICAL_PAGE_SPECS, max_year=2023,
    )
    if payload.get('coverage') != coverage:
        return None
    # Coverage expansion is logically stale even if the old timestamp is fresh.
    # The observed payload remains in RAM freshness state, enabling later retry.
    payload['ttl_seconds'] = 0
    return tuple(rows), payload


def _coverage_diagnostic():
    if (
        _listing_records_cache is not None
        and max(r.award_year for r in _listing_records_cache) < ARCHIVE_MAX_YEAR
    ):
        return (
            'Incomplete Newbery coverage: retained historical 1930–2023 fallback; '
            'the 2024–2026 update did not complete.'
        )
    return None


def _save_persistent_archive(records: tuple[_ListingRecord, ...]) -> None:
    try:
        cache.save_source_cache(
            SOURCE_KEY,
            CACHE_VERSION,
            records=[_record_to_cache_dict(record) for record in records],
            source_urls=_archive_source_urls(),
            coverage=_coverage_from_records(records),
            ttl_seconds=CACHE_TTL_SECONDS,
        )
    except OSError:
        pass


def _get_listing_records() -> tuple[_ListingRecord, ...]:
    """Return records: RAM, then disk, then live historical/annual HTML.

    A fresh disk cache is used immediately. A stale-but-valid disk cache
    live-refreshes only if this lookup still has a stale-refresh slot;
    otherwise the stale listing is used with no listing HTTP. A missing or
    invalid cache still live-fetches. Winner-page authors are never loaded
    here.
    """
    global _listing_records_cache
    with _cache_lock:
        if _listing_records_cache is not None:
            return _listing_records_cache
        disk = _load_persistent_archive()
        if disk is not None:
            records, payload = disk
            if cache.cache_is_fresh(payload):
                _listing_records_cache = records
                return records
            if not cache.try_claim_stale_refresh(SOURCE_KEY):
                _listing_records_cache = records
                return records
        else:
            records = None
        try:
            live = _load_live_archive()
            _validate_cached_archive(live)
        except Exception:
            if records is not None:
                _listing_records_cache = records
                return records
            raise
        _save_persistent_archive(live)
        _listing_records_cache = live
        return live


def _get_detail_author(
    opener: urllib.request.OpenerDirector,
    url: str,
) -> str:
    """Return a cached official author, fetching the winner page once."""
    with _cache_lock:
        cached = _detail_author_cache.get(url)
        if cached is not None:
            return cached
        html = _fetch_html(opener, url)
        author = _parse_detail_author(html)
        if author is None:
            raise NewberySourceError(
                'Newbery winner page did not contain a usable author byline '
                f'for {url}'
            )
        _detail_author_cache[url] = author
        return author


def _to_award_result(record: _ListingRecord, work_author: str) -> AwardResult:
    return AwardResult(
        work_title=record.work_title,
        work_author=work_author,
        award_name=AWARD_NAME,
        award_year=record.award_year,
        category=CATEGORY,
        status=record.status,
        rank=None,
        source_name=SOURCE_NAME,
        source_url=record.detail_url,
        notes=None,
        identity_kind='work',
    )


def lookup(
    title: str,
    author: str,
    series: str | None = None,
) -> list[AwardResult]:
    """Look up Newbery Medal results for a title and author (1930-2026)."""
    cleaned_title = title.strip()
    cleaned_author = author.strip()
    if not cleaned_title:
        raise ValueError('title must be a non-empty string')
    if not cleaned_author:
        raise ValueError('author must be a non-empty string')

    candidates = [
        record
        for record in _get_listing_records()
        if _titles_match(cleaned_title, record.work_title)
    ]
    if not candidates:
        return []

    opener = _build_opener()
    matches: list[AwardResult] = []
    seen: set[tuple[int, str, str, str, str]] = set()
    for record in candidates:
        official_author = record.work_author or _get_detail_author(
            opener, record.detail_url,
        )
        if not _record_authors_match(cleaned_author, official_author, record):
            continue
        key = (
            record.award_year,
            record.status,
            record.work_title.casefold(),
            official_author.casefold(),
            record.detail_url,
        )
        if key in seen:
            continue
        seen.add(key)
        matches.append(_to_award_result(record, official_author))
    return matches

# Coordinate RAM freshness and explicit refresh on retrieval workers.
import sys as _runtime_sys
from ..cache import source_runtime_guard as _runtime_guard
lookup = _runtime_guard(_runtime_sys.modules[__name__], lookup)
lookup.coverage_diagnostic = _coverage_diagnostic
_get_listing_records = _runtime_guard(_runtime_sys.modules[__name__], _get_listing_records)
