"""User-facing award-source capability metadata. Calibre-free and Qt-free.

SOURCE_INFOS describes what each source can do. It does not select sources,
run lookups, or qualify results. Keep keys and order aligned with
AWARD_SOURCES; tests enforce that, not a runtime import cycle.
"""

from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlparse

from .sources import (
    akutagawa,
    naoki,
    mao_dun,
    medicis,
    cwa_gold_dagger,
    dublin,
    diagram,
    bad_sex_fiction,
    balrog,
    booker,
    bram_stoker,
    edgar,
    international_booker,
    german_book_prize,
    hugo,
    ipaf,
    locus,
    miles_franklin,
    national_book_critics_circle,
    nebula,
    newbery,
    nobel,
    pen_faulkner,
    pen_hemingway,
    prix_goncourt,
    pulitzer,
    romantic_novel_awards,
    womens_prize_fiction,
    world_fantasy,
    wolfson_history,
)

_IDENTITY_SCOPES = frozenset({'work', 'series', 'author'})
_SCOPE_LABELS = {
    'work': 'Work awards',
    'series': 'Series awards',
    'author': 'Author awards',
}


@dataclass(frozen=True, slots=True)
class SourceInfo:
    """Static help metadata for one award source.

    Categories and identity scopes describe current lookup capabilities.
    They do not change lookup, matching, or qualification.
    """

    key: str
    display_name: str
    categories: tuple[str, ...]
    identity_scopes: tuple[str, ...]
    homepage_url: str
    description: str
    limitation: str | None = None

    def __post_init__(self) -> None:
        if not self.key or not self.key.strip() or self.key != self.key.strip():
            raise ValueError('key must be a non-empty string')
        if (
            not self.display_name
            or not self.display_name.strip()
            or self.display_name != self.display_name.strip()
        ):
            raise ValueError('display_name must be a non-empty string')
        if not self.categories:
            raise ValueError('categories must contain at least one label')
        if any(not label or not str(label).strip() for label in self.categories):
            raise ValueError('categories must contain non-empty labels')
        if not self.identity_scopes:
            raise ValueError('identity_scopes must contain at least one scope')
        if any(scope not in _IDENTITY_SCOPES for scope in self.identity_scopes):
            raise ValueError(
                "identity_scopes values must be 'work', 'series', or 'author'"
            )
        if not self.homepage_url or not self.homepage_url.strip():
            raise ValueError('homepage_url must be a non-empty string')
        parsed = urlparse(self.homepage_url.strip())
        if parsed.scheme != 'https' or not parsed.netloc:
            raise ValueError('homepage_url must be an https URL')
        if not self.description or not self.description.strip():
            raise ValueError('description must be a non-empty string')
        if self.limitation is not None and not self.limitation.strip():
            raise ValueError('limitation must be None or a non-empty string')


def _pulitzer_categories() -> tuple[str, ...]:
    return tuple(category for category, _url in pulitzer._CATEGORY_URLS)


def _nebula_categories() -> tuple[str, ...]:
    labels: list[str] = []
    for config in nebula._AWARD_CONFIGS:
        if config.award_name == nebula.AWARD_NAME_NEBULA:
            labels.append(config.category)
        else:
            labels.append(f'{config.award_name} — {config.category}')
    return tuple(labels)


def _hugo_categories() -> tuple[str, ...]:
    return hugo._PARSED_CATEGORIES


def _locus_categories() -> tuple[str, ...]:
    return tuple(locus._SUPPORTED_CATEGORY_LABELS)


def _world_fantasy_categories() -> tuple[str, ...]:
    return world_fantasy._CANONICAL_CATEGORIES


def _bram_stoker_categories() -> tuple[str, ...]:
    return bram_stoker.SOURCEINFO_CATEGORIES


def _edgar_categories() -> tuple[str, ...]:
    return edgar.SOURCEINFO_CATEGORIES


def _romantic_novel_awards_categories() -> tuple[str, ...]:
    return romantic_novel_awards.SOURCEINFO_CATEGORIES


def _nobel_categories() -> tuple[str, ...]:
    return (nobel.CATEGORY_LITERATURE,)


def _booker_categories() -> tuple[str, ...]:
    return (booker.CATEGORY,)


def _international_booker_categories() -> tuple[str, ...]:
    return international_booker.SOURCEINFO_CATEGORIES


def _wolfson_history_categories() -> tuple[str, ...]:
    return wolfson_history.SOURCEINFO_CATEGORIES


def _german_book_prize_categories() -> tuple[str, ...]:
    return (german_book_prize.CATEGORY,)


def _prix_goncourt_categories() -> tuple[str, ...]:
    return (prix_goncourt.CATEGORY,)


def _miles_franklin_categories() -> tuple[str, ...]:
    return (miles_franklin.CATEGORY,)


def _womens_prize_fiction_categories() -> tuple[str, ...]:
    return (womens_prize_fiction.CATEGORY,)


def _nbcc_categories() -> tuple[str, ...]:
    return national_book_critics_circle._SOURCEINFO_CATEGORIES


def _pen_faulkner_categories() -> tuple[str, ...]:
    return (pen_faulkner.CATEGORY,)


def _pen_hemingway_categories() -> tuple[str, ...]:
    return (pen_hemingway.CATEGORY,)


def _ipaf_categories() -> tuple[str, ...]:
    return (ipaf.CATEGORY,)


def _newbery_categories() -> tuple[str, ...]:
    return (newbery.CATEGORY,)


def format_identity_scopes(scopes: tuple[str, ...]) -> str:
    """Return comma-separated user-facing labels for identity scopes."""
    return ', '.join(_SCOPE_LABELS[scope] for scope in scopes)


def format_source_info(info: SourceInfo) -> str:
    """Return a plain-text help block for one source."""
    lines = [
        info.display_name,
        f'Categories: {", ".join(info.categories)}',
        f'Scope: {format_identity_scopes(info.identity_scopes)}',
        info.description.strip(),
    ]
    if info.limitation is not None:
        lines.append(f'Note: {info.limitation.strip()}')
    return '\n'.join(lines)


SOURCE_INFOS: tuple[SourceInfo, ...] = (
    SourceInfo(
        key='pulitzer',
        display_name='Pulitzer Prizes',
        categories=_pulitzer_categories(),
        identity_scopes=('work',),
        homepage_url=pulitzer.SOURCE_HOME_URL,
        description='Fiction and Novel awards from Pulitzer.org.',
        limitation=(
            'Pulitzer.org may block unattended retrieval. A reviewed snapshot '
            'of official Fiction and Novel award facts through 2026 is used '
            'as the baseline. Live official refresh remains opportunistic. A '
            'failed refresh does not discard usable Pulitzer data.'
        ),
    ),
    SourceInfo(
        key='nebula',
        display_name='Nebula Awards',
        categories=_nebula_categories(),
        identity_scopes=('work',),
        homepage_url=nebula.SOURCE_HOME_URL,
        description='Nebula and Andre Norton literary award results.',
    ),
    SourceInfo(
        key='hugo',
        display_name='Hugo Awards',
        categories=_hugo_categories(),
        identity_scopes=('work', 'series'),
        homepage_url=hugo.SOURCE_HOME_URL,
        description=(
            'Hugo work awards and supported series awards, including '
            'historical category names where applicable.'
        ),
    ),
    SourceInfo(
        key='locus',
        display_name='Locus Awards',
        categories=_locus_categories(),
        identity_scopes=('work',),
        homepage_url=locus.SFADB_ORIGIN,
        description=(
            'Ranked Locus literary awards from the Science Fiction Awards '
            'Database.'
        ),
    ),
    SourceInfo(
        key='world_fantasy',
        display_name='World Fantasy Awards',
        categories=_world_fantasy_categories(),
        identity_scopes=('work',),
        homepage_url=world_fantasy.SOURCE_HOME_URL,
        description=(
            'World Fantasy work awards in the supported literary categories.'
        ),
    ),
    SourceInfo(
        key='balrog',
        display_name='Balrog Award',
        categories=balrog.CATEGORIES,
        identity_scopes=('work',),
        homepage_url=balrog.SOURCE_HOME_URL,
        description=(
            'Balrog literary awards from the Internet Speculative Fiction '
            'Database public copy at stoecker.eu. Winners and source-labeled '
            'Nominations are matched by title and author.'
        ),
        limitation=(
            'Award years 1979–1985. Novel, Short Fiction, Short Story, '
            'Collection and Collection/Anthology category names are preserved. '
            'The 1984–1985 literary records are winner-only. Nominations '
            'require review; no ordinal rank is inferred. Film, person, '
            'publication and achievement honors are excluded. This is a '
            'third-party ISFDB copy; original-site access may be blocked.'
        ),
    ),
    SourceInfo(
        key='bram_stoker',
        display_name='Bram Stoker Awards',
        categories=_bram_stoker_categories(),
        identity_scopes=('work',),
        homepage_url=bram_stoker.SOURCE_HOME_URL,
        description=(
            'Horror Writers Association awards for superior achievement in '
            'horror and dark literature. Returns Winners and official Final '
            'Ballot works in bibliographic categories.'
        ),
        limitation=(
            'Coverage begins with the 1987 award cycle. Award year is the '
            'publication year, although Winners are announced the following '
            'year. Final Ballot works are returned as Finalists; Preliminary '
            'Ballot and recommendation list appearances are ignored. '
            'Screenplay, other-media, Lifetime Achievement, service, and '
            'press honors are excluded. Historical category names are '
            'preserved and ties may produce multiple Winners. No ordinal '
            'rank is inferred.'
        ),
    ),
    SourceInfo(
        key='edgar',
        display_name='Edgar Awards',
        categories=_edgar_categories(),
        identity_scopes=('work',),
        homepage_url=edgar.SOURCE_HOME_URL,
        description=(
            'Mystery Writers of America Edgar Awards for mystery and crime '
            'fiction and nonfiction. Returns official Winners and Nominees '
            'in bibliographic categories.'
        ),
        limitation=(
            'Coverage begins in 1946. Award year is the ceremony year and '
            'generally honors prior-year publication. Nominees are official '
            'announced nominee slates and do not imply rank. Early years are '
            'often winner-only. Robert L. Fish Nominees appear in the official '
            'database only from 2024. Media, screen, stage, person, service, '
            'design, and Special Edgar categories are excluded.'
        ),
    ),
    SourceInfo(
        key='romantic_novel_awards',
        display_name='Romantic Novel of the Year Awards',
        categories=_romantic_novel_awards_categories(),
        identity_scopes=('work',),
        homepage_url=romantic_novel_awards.SOURCE_HOME_URL,
        description=(
            'Romantic Novelists\' Association awards recognizing published '
            'romantic fiction across multiple subgenres.'
        ),
        limitation=(
            'The winners archive begins in 1960. The current first-party '
            'archive omits 1966 and 2011-2017. Official shortlist coverage '
            'on the current site begins in 2018. Historical category names '
            'are preserved. Industry and person awards and the Joan '
            'Hessayon Award are excluded.'
        ),
    ),
    SourceInfo(
        key='nobel',
        display_name='Nobel Award',
        categories=_nobel_categories(),
        identity_scopes=('author',),
        homepage_url=nobel.SOURCE_HOME_URL,
        description=(
            'Nobel Prize in Literature results awarded to the author and '
            'shown as [Author: Name]. Check Awards displays the official '
            'English prize motivation. A small reviewed set of works '
            'explicitly named in that motivation receives a citation '
            'annotation; those books are not treated as Nobel Winners.'
        ),
        limitation=(
            'Editorial Nobel work lists, biographies, and bibliographies are '
            'not harvested as award facts. Ordinary books by a laureate are '
            'not claimed to have won the Nobel Prize. Mikhail Sholokhov\'s '
            '1965 phrase "his epic of the Don" is not treated as a title.'
        ),
    ),
    SourceInfo(
        key='booker',
        display_name='The Booker Prize',
        categories=_booker_categories(),
        identity_scopes=('work',),
        homepage_url=booker.SOURCE_HOME_URL,
        description=(
            'Booker Prize winners and shortlisted works from the official '
            'Booker Prize archive.'
        ),
        limitation='Longlisted-only works are not returned.',
    ),
    SourceInfo(
        key='international_booker',
        display_name='International Booker Prize',
        categories=_international_booker_categories(),
        identity_scopes=('work',),
        homepage_url=international_booker.SOURCE_HOME_URL,
        description=(
            'Official International Booker Prize Winner and Shortlisted '
            'translated works from 2016 onward. This implementation covers '
            'the modern work-level prize through 2026.'
        ),
        limitation=(
            'The 2005-2015 biennial Man Booker International Prize honoured '
            'an author\'s body of work rather than a single book and is not '
            'returned. Longlisted-only works are not returned. 2027 is not '
            'emitted yet because the official prize name changes to the '
            'Bukhman International Booker Prize and competitive results do '
            'not yet exist. Translator credit is stored as notes rather than '
            'emitted as a separate award.'
        ),
    ),
    SourceInfo(
        key='wolfson_history',
        display_name='Wolfson History Prize',
        categories=_wolfson_history_categories(),
        identity_scopes=('work',),
        homepage_url=wolfson_history.SOURCE_HOME_URL,
        description=(
            'Official Wolfson History Prize book awards from 1972 onward. '
            'Historical years may have more than one co-equal Winner. '
            'Official shortlist coverage begins in 2017.'
        ),
        limitation=(
            'The official archive omits 1988. Lifetime and '
            'distinguished-contribution honors are excluded. Shortlist '
            'order and the order of historical Winners do not imply rank. '
            'The current award cycle can list a shortlist before a Winner '
            'is announced.'
        ),
    ),
    SourceInfo(
        key='german_book_prize',
        display_name='Deutscher Buchpreis',
        categories=_german_book_prize_categories(),
        identity_scopes=('work',),
        homepage_url=german_book_prize.ARCHIVE_INDEX_URL,
        description=(
            'German Book Prize (Deutscher Buchpreis) winners and shortlisted '
            'novels from the official archive.'
        ),
        limitation='Longlisted-only works are not returned.',
    ),
    SourceInfo(
        key='prix_goncourt',
        display_name='Prix Goncourt',
        categories=_prix_goncourt_categories(),
        identity_scopes=('work',),
        homepage_url=prix_goncourt.SOURCE_HOME_URL,
        description=(
            'Prix Goncourt winners from the official Académie Goncourt '
            'archive; French-language fiction.'
        ),
        limitation=(
            'Winners are available from the complete official archive '
            'beginning in 1903. Finalists from the Académie Goncourt '
            '3ème sélection are included from 2018 onward. First- and '
            'second-selection-only works are not returned.'
        ),
    ),
    SourceInfo(
        key='miles_franklin',
        display_name='Miles Franklin Literary Award',
        categories=_miles_franklin_categories(),
        identity_scopes=('work',),
        homepage_url=miles_franklin.SOURCE_HOME_URL,
        description=(
            'Miles Franklin Literary Award winners and officially labeled '
            'shortlist/finalist novels from Perpetual\'s judges and history '
            'of recipients archive.'
        ),
        limitation=(
            'Official production coverage begins in 2007. Finalists are '
            'included only when the history page labels the work Finalist, '
            'Shortlist, or Shortlisted. The 2025 nonwinning shortlist is not '
            'returned because that page does not distinguish those works from '
            'longlist-only works. Longlist-only works are not returned. '
            'Pre-2007 winners are not available from this archive.'
        ),
    ),
    SourceInfo(
        key='womens_prize_fiction',
        display_name="Women's Prize for Fiction",
        categories=_womens_prize_fiction_categories(),
        identity_scopes=('work',),
        homepage_url=womens_prize_fiction.SOURCE_HOME_URL,
        description=(
            "Women's Prize for Fiction winners from the official "
            'previous-prizes archive and current prize page, plus official '
            'shortlisted works from first-party shortlist announcements.'
        ),
        limitation=(
            'Official Winner coverage begins in 1996. Historical Orange '
            'Prize for Fiction years are treated as the same prize under '
            'its current name. Shortlisted works are covered from 2017 '
            'onward. Longlisted-only works are not returned. The Women\'s '
            'Prize for Non-Fiction, Discoveries, and other Women\'s Prize '
            'programmes are excluded.'
        ),
    ),
    SourceInfo(
        key='national_book_critics_circle',
        display_name='National Book Critics Circle Awards',
        categories=_nbcc_categories(),
        identity_scopes=('work',),
        homepage_url=national_book_critics_circle.SOURCE_HOME_URL,
        description=(
            'Official National Book Critics Circle year archive: Winners and '
            'Finalists in the core book categories, plus the John Leonard '
            'Prize and Gregg Barrios Book in Translation Prize.'
        ),
        limitation=(
            "Award year is the book's publication/archive year, not the later "
            'ceremony date. Winner coverage begins in 1975; Finalists begin in '
            '1976. Historical category labels such as General Nonfiction, '
            'Biography/Autobiography, and Autobiography/Memoir are preserved. '
            'Longlisted-only works are not returned. Reviewing citations, '
            'lifetime/institution honors, and fellowships are excluded.'
        ),
    ),
    SourceInfo(
        key='pen_faulkner',
        display_name='PEN/Faulkner Award for Fiction',
        categories=_pen_faulkner_categories(),
        identity_scopes=('work',),
        homepage_url=pen_faulkner.SOURCE_HOME_URL,
        description=(
            'Official PEN/Faulkner Award for Fiction Winners and Finalists. '
            'Eligible works include novels, novellas, and short-story '
            'collections.'
        ),
        limitation=(
            'Winner and Finalist coverage begins in 1981. Award year is the '
            'ceremony/award year, not the eligibility publication year. '
            'Longlisted-only works are not returned. The PEN/Hemingway Award, '
            'PEN/Malamud Award, and PEN/Faulkner Literary Champion are '
            'excluded. Historical Finalist counts vary and no ordinal rank '
            'is inferred.'
        ),
    ),
    SourceInfo(
        key='pen_hemingway',
        display_name='PEN/Hemingway Award for Debut Novel',
        categories=_pen_hemingway_categories(),
        identity_scopes=('work',),
        homepage_url=pen_hemingway.SOURCE_HOME_URL,
        description=(
            'Official PEN/Hemingway Award for Debut Novel Winners, plus '
            'Finalists from the PEN/Faulkner administration. Historical '
            'winners include first books of fiction; current guidelines '
            'are for debut novels.'
        ),
        limitation=(
            'Winner coverage begins in 1976. Award year is the '
            'ceremony/award year, not the eligibility publication year. '
            'Finalists are included from 2026, when administration '
            'transferred to the PEN/Faulkner Foundation. Historical '
            'Finalists, Runners-up, and Honorable Mentions from prior '
            'administrators are not returned. '
            'Longlisted-only works are not returned. The PEN/Faulkner '
            'Award for Fiction, PEN/Malamud Award, and PEN/Faulkner '
            'Literary Champion are excluded. No ordinal rank is inferred.'
        ),
    ),
    SourceInfo(
        key='ipaf',
        display_name='International Prize for Arabic Fiction',
        categories=_ipaf_categories(),
        identity_scopes=('work',),
        homepage_url=ipaf.SOURCE_HOME_URL,
        description=(
            'Official Winners and Shortlisted novels originally written '
            'in Arabic for the International Prize for Arabic Fiction. '
            'IPAF also supports international translation of recognized '
            'novels.'
        ),
        limitation=(
            'Coverage currently follows populated official English '
            'prize-year pages from 2020 onward; IPAF\'s earlier 2008-2019 '
            'archive has not yet been migrated to the current site. '
            'Longlisted-only works are not returned. Titles and author '
            'names use IPAF\'s official English forms and may differ from '
            'earlier announcements or later published translations. No '
            'generated transliteration or ordinal rank is used.'
        ),
    ),
    SourceInfo(
        key='bad_sex_fiction', display_name='Bad Sex in Fiction Award',
        categories=bad_sex_fiction.CATEGORIES, identity_scopes=('work',),
        homepage_url=bad_sex_fiction.SOURCE_HOME_URL,
        description='Literary Review satirical fiction prize, matched by title and author.',
        limitation=('Bundled reviewed winners for 1993–2019, including both 2019 winners. '
                    'Winner-only; shortlists and John Updike’s lifetime achievement are excluded. '
                    '2020 was cancelled. No live retrieval; Refresh reloads the bundled archive. '
                    'Earlier gaps and the 1994/1995 date discrepancy use a historical secondary source.'),
    ),
    SourceInfo(
        key='diagram', display_name=diagram.AWARD_NAME,
        categories=diagram.CATEGORIES, identity_scopes=('work',),
        homepage_url=diagram.SOURCE_HOME_URL,
        description='The Bookseller’s humorous prize recognizing the oddest book title.',
        limitation=('42 bundled annual winners with identified authors/editors, 1979–2025. '
                    'Historical secondary-source attribution is retained. '
                    '1978, 1981 and 1982 lack usable credited identities and are excluded; '
                    '1987, 1991 and 2017 had no award. Shortlists and Diagram of Diagrams '
                    'anniversary awards are excluded. No live retrieval; Refresh reloads '
                    'the bundled archive. Award year may precede the announcement year.'),
    ),
    SourceInfo(
        key='newbery',
        display_name='John Newbery Medal',
        categories=_newbery_categories(),
        identity_scopes=('work',),
        homepage_url=newbery.SOURCE_HOME_URL,
        description=(
            'Newbery Medal winners and Honor Books from the official ALA '
            'HTML archive.'
        ),
        limitation=(
            'Current plugin coverage begins in 1930 and ends in 2026.'
        ),
    ),
    SourceInfo(
        key='dublin', display_name=dublin.AWARD_NAME, categories=dublin.CATEGORIES,
        identity_scopes=('work',), homepage_url=dublin.SOURCE_HOME_URL,
        description='Official Dublin Literary Award winners, shortlisted, longlisted and nominated novels, including English translations.',
        limitation=('Coverage begins in 1996, including the former International IMPAC Dublin naming. '
                    'Award years and credited English titles/authors follow the official archive. '
                    'Nominated, Longlisted and Shortlisted results are shown for REVIEW, unchecked by default. The official 2013 longlist is empty, so that year covers finalists only. Translators are not treated '
                    'as authors. No ordinal rank is inferred. First download fetches annual pages and complete candidate lists; '
                    'subsequent lookups use saved data. Failed refresh retains validated fallback.'),
    ),
    SourceInfo(
        key='akutagawa', display_name=akutagawa.AWARD_NAME, categories=akutagawa.CATEGORIES,
        identity_scopes=('work',), homepage_url=akutagawa.SOURCE_HOME_URL,
        description='Official Akutagawa Prize winners and documented nominations for Japanese literary fiction.',
        limitation=('Winner history begins in 1935. Nomination coverage is limited to rounds 162 (2019 second half) '
                    'and 175 (2026 first half), from complete Bungeishunju announcements. '
                    'Eight winning works and one nominee have reviewed English title/name mappings; other titles match '
                    'the original Japanese records only. No automatic translation, author-wide award attribution, '
                    'collection or expanded-edition matching. Nominations appear unchecked for REVIEW. '
                    'Official half-year and round are retained; January announcements use the preceding award year. '
                    'Refresh downloads the official winner archive and documented nomination pages, retaining validated fallback.'),
    ),
    SourceInfo(
        key='naoki', display_name=naoki.AWARD_NAME, categories=naoki.CATEGORIES,
        identity_scopes=('work',), homepage_url=naoki.SOURCE_HOME_URL,
        description='Official Naoki Prize winners and documented nominations for Japanese entertainment fiction.',
        limitation=('Winner history begins in 1935. Nomination coverage is limited to round 175 (2026 first half). '
                    'Two winning works have reviewed English title/name mappings; other entries require original Japanese identities. '
                    'Multi-story citations remain intact; individual stories and translated collections are not inferred. '
                    'No automatic translation or author-wide awards. Nominations appear unchecked for REVIEW. '
                    'Official year and half are retained. Refresh keeps validated fallback on failure. '
                    'The separate High School Students’ Naoki Prize is excluded.'),
    ),
    SourceInfo(
        key='mao_dun', display_name=mao_dun.AWARD_NAME, categories=mao_dun.CATEGORIES,
        identity_scopes=('work',), homepage_url=mao_dun.SOURCE_HOME_URL,
        description='Official Mao Dun Literature Prize novels, honorary awards and documented nominees.',
        limitation=('Reviewed editions 1–11 (award years 1982–2023); actual award years are distinct from eligibility periods. '
                    'Nominations are limited to edition 11 (2023). Two English winning-work mappings are reviewed; '
                    'other entries require original Chinese identities. No automatic translation or author-wide awards. '
                    'Honorary awards remain distinct and unchecked for REVIEW; nominees also start unchecked. '
                    'Explicit awarded volumes, trilogies and revised editions require identity confirmation. '
                    'New editions, nomination coverage and English mappings require a reviewed plugin update. '
                    'Refresh downloads official records and retains validated fallback on failure.'),
    ),
    SourceInfo(
        key='medicis', display_name=medicis.AWARD_NAME, categories=medicis.CATEGORIES,
        identity_scopes=('work',), homepage_url=medicis.SOURCE_HOME_URL,
        description='Official Médicis French, foreign and essay winners and documented selected novels.',
        limitation=('Winner history begins in 1958 (French), 1970 (foreign), and 1985 (essay); '
                    'the official archive omits essay results for 1988 and 1993. Joint winners are retained. '
                    'Candidate coverage is limited to the 2026 first selection: 18 French and 17 foreign novels, '
                    'shown unchecked for REVIEW as Selected, with the actual selection round retained. '
                    'One English title mapping is verified: The Mars Room / Rachel Kushner; other works require '
                    'French source titles. No automatic translation, ordinal rank or author-wide awards. '
                    'Specific volumes require confirmation. Refresh retains validated fallback; new selection rounds '
                    'and mappings require a reviewed plugin update.'),
    ),
    SourceInfo(
        key='cwa_gold_dagger', display_name=cwa_gold_dagger.AWARD_NAME,
        categories=cwa_gold_dagger.CATEGORIES, identity_scopes=('work',),
        homepage_url=cwa_gold_dagger.SOURCE_HOME_URL,
        description='Official main CWA Gold Dagger crime novels and its continuous Crossed Red Herrings predecessor.',
        limitation=('Verified winner coverage is 1955–2026, combining the Gold archive, predecessor filter '
                    'and the individual 2021 winner page omitted from the archive. Explicit Shortlisted, '
                    'Longlisted and Highly Commended distinctions are REVIEW, unchecked; candidate history is partial. '
                    'The undated Bluebird, Bluebird shortlist record is excluded; no year is guessed. '
                    'Original credits are retained; the 1963 winner has a verified record-specific John le Carré alias. Other Daggers '
                    '(including non-fiction and translation-specific awards) are excluded. '
                    'Unpublished future-year results are not inferred. Refresh retains validated fallback on failure.'),
    ),
)
