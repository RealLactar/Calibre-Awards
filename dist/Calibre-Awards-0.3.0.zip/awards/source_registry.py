"""Executable award lookup sources, in user-visible order.

This is the set of sources the engine can run. SOURCE_INFOS describes the
same sources for help text; tests keep the two lists aligned. Source lookup
callables must not read Calibre preferences — the engine filters enabled
keys before scheduling.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from .model import AwardResult
from .sources.dublin import lookup as dublin_lookup
from .sources.akutagawa import lookup as akutagawa_lookup
from .sources.naoki import lookup as naoki_lookup
from .sources.mao_dun import lookup as mao_dun_lookup
from .sources.medicis import lookup as medicis_lookup
from .sources.cwa_gold_dagger import lookup as cwa_gold_dagger_lookup
from .sources.diagram import lookup as diagram_lookup
from .sources.bad_sex_fiction import lookup as bad_sex_fiction_lookup
from .sources.balrog import lookup as balrog_lookup
from .sources.booker import lookup as booker_lookup
from .sources.bram_stoker import lookup as bram_stoker_lookup
from .sources.international_booker import lookup as international_booker_lookup
from .sources.edgar import lookup as edgar_lookup
from .sources.german_book_prize import lookup as german_book_prize_lookup
from .sources.hugo import lookup as hugo_lookup
from .sources.ipaf import lookup as ipaf_lookup
from .sources.prix_goncourt import lookup as prix_goncourt_lookup
from .sources.locus import lookup as locus_lookup
from .sources.miles_franklin import lookup as miles_franklin_lookup
from .sources.national_book_critics_circle import (
    lookup as national_book_critics_circle_lookup,
)
from .sources.nebula import lookup as nebula_lookup
from .sources.newbery import lookup as newbery_lookup
from .sources.pen_faulkner import lookup as pen_faulkner_lookup
from .sources.pen_hemingway import lookup as pen_hemingway_lookup
from .sources.nobel import lookup as nobel_lookup
from .sources.pulitzer import lookup as pulitzer_lookup
from .sources.romantic_novel_awards import lookup as romantic_novel_awards_lookup
from .sources.womens_prize_fiction import lookup as womens_prize_fiction_lookup
from .sources.world_fantasy import lookup as world_fantasy_lookup
from .sources.wolfson_history import lookup as wolfson_history_lookup


class AwardSourceLookup(Protocol):
    """Lookup callable: title and author required; series optional."""

    def __call__(
        self,
        title: str,
        author: str,
        series: str | None = None,
    ) -> list[AwardResult]: ...


@dataclass(frozen=True, slots=True)
class AwardSource:
    """One award lookup source. Source-neutral; no qualification or GUI logic."""

    key: str
    display_name: str
    lookup: AwardSourceLookup


AWARD_SOURCES: tuple[AwardSource, ...] = (
    AwardSource(
        key='pulitzer',
        display_name='Pulitzer Prizes',
        lookup=pulitzer_lookup,
    ),
    AwardSource(
        key='nebula',
        display_name='Nebula Awards',
        lookup=nebula_lookup,
    ),
    AwardSource(
        key='hugo',
        display_name='Hugo Awards',
        lookup=hugo_lookup,
    ),
    AwardSource(
        key='locus',
        display_name='Locus Awards',
        lookup=locus_lookup,
    ),
    AwardSource(
        key='world_fantasy',
        display_name='World Fantasy Awards',
        lookup=world_fantasy_lookup,
    ),
    AwardSource(
        key='balrog',
        display_name='Balrog Award',
        lookup=balrog_lookup,
    ),
    AwardSource(
        key='bram_stoker',
        display_name='Bram Stoker Awards',
        lookup=bram_stoker_lookup,
    ),
    AwardSource(
        key='edgar',
        display_name='Edgar Awards',
        lookup=edgar_lookup,
    ),
    AwardSource(
        key='romantic_novel_awards',
        display_name='Romantic Novel of the Year Awards',
        lookup=romantic_novel_awards_lookup,
    ),
    AwardSource(
        key='nobel',
        display_name='Nobel Award',
        lookup=nobel_lookup,
    ),
    AwardSource(
        key='booker',
        display_name='The Booker Prize',
        lookup=booker_lookup,
    ),
    AwardSource(
        key='international_booker',
        display_name='International Booker Prize',
        lookup=international_booker_lookup,
    ),
    AwardSource(
        key='wolfson_history',
        display_name='Wolfson History Prize',
        lookup=wolfson_history_lookup,
    ),
    AwardSource(
        key='german_book_prize',
        display_name='Deutscher Buchpreis',
        lookup=german_book_prize_lookup,
    ),
    AwardSource(
        key='prix_goncourt',
        display_name='Prix Goncourt',
        lookup=prix_goncourt_lookup,
    ),
    AwardSource(
        key='miles_franklin',
        display_name='Miles Franklin Literary Award',
        lookup=miles_franklin_lookup,
    ),
    AwardSource(
        key='womens_prize_fiction',
        display_name="Women's Prize for Fiction",
        lookup=womens_prize_fiction_lookup,
    ),
    AwardSource(
        key='national_book_critics_circle',
        display_name='National Book Critics Circle Awards',
        lookup=national_book_critics_circle_lookup,
    ),
    AwardSource(
        key='pen_faulkner',
        display_name='PEN/Faulkner Award for Fiction',
        lookup=pen_faulkner_lookup,
    ),
    AwardSource(
        key='pen_hemingway',
        display_name='PEN/Hemingway Award for Debut Novel',
        lookup=pen_hemingway_lookup,
    ),
    AwardSource(
        key='ipaf',
        display_name='International Prize for Arabic Fiction',
        lookup=ipaf_lookup,
    ),
    AwardSource(key='bad_sex_fiction', display_name='Bad Sex in Fiction Award',
                lookup=bad_sex_fiction_lookup),
    AwardSource(key='diagram', display_name='Diagram Prize for Oddest Title of the Year',
                lookup=diagram_lookup),
    AwardSource(
        key='newbery',
        display_name='John Newbery Medal',
        lookup=newbery_lookup,
    ),
    AwardSource(key='dublin', display_name='Dublin Literary Award', lookup=dublin_lookup),
    AwardSource(key='akutagawa', display_name='Akutagawa Prize', lookup=akutagawa_lookup),
    AwardSource(key='naoki', display_name='Naoki Prize', lookup=naoki_lookup),
    AwardSource(key='mao_dun', display_name='Mao Dun Literature Prize', lookup=mao_dun_lookup),
    AwardSource(key='medicis', display_name='Prix Médicis', lookup=medicis_lookup),
    AwardSource(key='cwa_gold_dagger', display_name='CWA Gold Dagger', lookup=cwa_gold_dagger_lookup),
)
